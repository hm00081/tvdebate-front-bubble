/* eslint-disable no-unused-vars */
import React, {
  forwardRef,
  Ref,
  useEffect,
  useRef,
  useState,
  useImperativeHandle,
} from "react";
import { useLocation } from "react-router-dom";
import styles from "./ConceptualMapModal.module.scss";
import { ConceptualMapDrawer } from "./ConceptualMapDrawer";
import { SimilarityBlock, UtteranceObjectForDrawing } from "../interfaces";
import { GraphDataStructureMaker } from "./GraphDataStructureMaker";
import * as math from "mathjs";
import _ from "lodash";
import ConceptualMapControllers from "./ConceptualMapControllers/ConceptualMapControllers";
import { ParticipantDict } from "../../../common_functions/makeParticipants";
import {
  DebateDataSet,
  UtteranceObject,
  EvaluationDataSet,
} from "../../../interfaces/DebateDataInterface";
import DataImporter, { DebateName, TermType } from "../DataImporter";
import { DataStructureManager } from "../DataStructureMaker/DataStructureManager";
import CombinedEGsMaker from "../DataStructureMaker/CombinedEGsMaker";
import { useSelector, useDispatch } from "react-redux";
import { CHANGE_STANDARD_SIMILARITY_SCORE } from "../../../redux/actionTypes";
import { extractKeytermsFromEngagementGroup } from "../DataStructureMaker/extractTermsFromEngagementGroup";
import { D3Drawer } from "../Drawers/D3Drawer";

const modalContentWidth: number = 800;
const modalContentHeight: number = 600;
const conceptualMapDivClassName: string = "conceptual-map";

export interface ConceptualMapModalRef {
  openModal: (modalTitle: string, engagementGroup: SimilarityBlock[][]) => void;
}

interface ComponentProps {
  participantDict: ParticipantDict;
  utteranceObjects: UtteranceObject[];
  termUtteranceBooleanMatrixTransposed: number[][];
  termList: string[];
  termType: TermType;
  drawGraph: (
    index: number,
    engagementGroup: SimilarityBlock[][],
    manualBigEGs: SimilarityBlock[][][]
  ) => void;
  manualBigEGs: SimilarityBlock[][][]; // 추가
}

function ConceptualMapModal(
  props: ComponentProps,
  ref: Ref<ConceptualMapModalRef>
) {
  const modalRef = useRef<HTMLDivElement>(null);
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [modalTitle, setModalTitle] = useState<string>("");
  const [maxCooccurrence, setMaxCooccurrence] = useState<number>(0);
  const [
    standardTermCountToGenerateNode,
    setStandardTermCountToGenerateNode,
  ] = useState<number>(0);
  const [maxCountPerNodes, setMaxCountPerNodes] = useState<number>(10);
  const [maxOfLinksPerNode, setMaxOfLinksPerNode] = useState<number>(3);
  const [showNodeNotHavingLinks, setShowNodeNotHavingLinks] = useState<boolean>(
    true
  );
  const [conceptualMapDrawer, setConceptualMapDrawer] = useState<
    ConceptualMapDrawer
  >(); // imply svg
  const [graphDataStructureMaker, setGraphDataStructureMaker] = useState<
    GraphDataStructureMaker
  >();
  // migration to CRP to CMM
  const query = new URLSearchParams(useLocation().search);
  const debateNameOfQuery = query.get("debate_name") as DebateName;
  const termTypeOfQuery = query.get("term_type") as TermType;
  const [debateDataset, setDebateDataset] = useState<DebateDataSet | null>(
    null
  );
  const [manualBigEGs, setManualBigEGs] = useState<SimilarityBlock[][][]>([]);
  // console.log(debateDataset);
  const [
    dataStructureManager,
    setDataStructureManager,
  ] = useState<DataStructureManager | null>(null);
  const [
    evaluationDataSet,
    setEvaluationDataSet,
  ] = useState<EvaluationDataSet | null>(null);
  const [
    combinedEGsMaker,
    setCombinedEGsMaker,
  ] = useState<CombinedEGsMaker | null>(null);
  const [conceptualMapDrawers, setConceptualMapDrawers] = useState<
    ConceptualMapDrawer[]
  >([]);
  const [engagementGroups, setEngagementGroups] = useState<
    SimilarityBlock[][][]
  >([]);
  const [localManualBigEGs, setLocalManualBigEGs] = useState<
    SimilarityBlock[][][]
  >([]);
  const [manualBigEGsFromDSM, setManualBigEGsFromDSM] = useState<
    SimilarityBlock[][][]
  >([]);
  const dispatch = useDispatch();
  const openModal = (
    modalTitle: string,
    engagementGroup: SimilarityBlock[][]
    //manualBigEGs: SimilarityBlock[][]
  ) => {
    setModalVisible(true);
    setModalTitle(modalTitle);

    // 그래프를 그리는 로직
    if (conceptualMapDrawer) {
      conceptualMapDrawer.removeDrawing();

      const graphDataStructureMaker = new GraphDataStructureMaker(
        engagementGroup,
        props.participantDict,
        props.utteranceObjects,
        props.termType
      );

      const cooccurrenceMatrixOfEG = graphDataStructureMaker.getCooccurrenceMatrixOfEG();
      const ceiledMedian = Math.ceil(math.mean(cooccurrenceMatrixOfEG));

      const nodeLinkDict = graphDataStructureMaker.generateNodesAndLinks(
        ceiledMedian,
        maxOfLinksPerNode,
        showNodeNotHavingLinks
      );

      conceptualMapDrawer.setGraphData(nodeLinkDict);
      conceptualMapDrawer.updateGraph();
    }
  };

  const drawGraph = (index: number) => {
    const conceptualMapDrawer = conceptualMapDrawers[index];

    // conceptualMapDrawer가 정의되어 있는지 확인
    if (conceptualMapDrawer) {
      conceptualMapDrawer.removeDrawing();

      // manualBigEGs를 사용하는 로직
      const selectedManualBigEG = manualBigEGsFromDSM[index];

      // manualBigEG를 사용하여 GraphDataStructureMaker를 생성합니다.
      const graphDataStructureMaker = new GraphDataStructureMaker(
        selectedManualBigEG,
        props.participantDict,
        props.utteranceObjects,
        props.termType
      );

      const cooccurrenceMatrixOfEG = graphDataStructureMaker.getCooccurrenceMatrixOfEG();
      const ceiledMedian = Math.ceil(math.mean(cooccurrenceMatrixOfEG));

      const nodeLinkDict = graphDataStructureMaker.generateNodesAndLinks(
        ceiledMedian,
        maxOfLinksPerNode,
        showNodeNotHavingLinks
      );

      conceptualMapDrawer.setGraphData(nodeLinkDict);
      conceptualMapDrawer.updateGraph();
    }
  };

  useEffect(() => {
    if (dataStructureManager) {
      const datasetOfManualEGs = dataStructureManager.datasetOfManualEGs;
      const manualBigEGs = datasetOfManualEGs.manualBigEGs;
      setManualBigEGsFromDSM(manualBigEGs);
      console.log(manualBigEGs);
    }
  }, [dataStructureManager]);

  //기존 useEffect 코드 아래에 추가
  useEffect(() => {
    if (combinedEGsMaker) {
      const modalPadding = 24;
      //console.log(combinedEGsMaker);
      let engagementGroups = combinedEGsMaker.makeByNumOfSegments(10);

      // 추가: engagementGroups를 상태로 저장합니다.
      setEngagementGroups(engagementGroups);

      const newConceptualMapDrawers = engagementGroups.map((_, index) => {
        // console.log(_, index);
        const newConceptualMapDrawer: ConceptualMapDrawer = new ConceptualMapDrawer(
          `.${conceptualMapDivClassName}-${index}`,
          (modalContentWidth - modalPadding * 2) / 4,
          (modalContentHeight - modalPadding * 2) / 2,
          props.participantDict
        );
        if (conceptualMapDrawers.length > 0) {
          conceptualMapDrawers.forEach((drawer) => drawer.removeDrawing());
        }
        return newConceptualMapDrawer;
      });

      setConceptualMapDrawers(newConceptualMapDrawers);
    }
  }, [combinedEGsMaker]);

  useEffect(() => {
    if (combinedEGsMaker) {
      let engagementGroups = combinedEGsMaker.makeByNumOfSegments(3);

      // 추가: engagementGroups를 상태로 저장합니다.
      setEngagementGroups(engagementGroups);
    }
  }, [combinedEGsMaker]);

  useEffect(() => {
    if (
      conceptualMapDrawers.length > 0 &&
      combinedEGsMaker &&
      manualBigEGsFromDSM.length > 0
    ) {
      manualBigEGsFromDSM.forEach((_, index) => {
        drawGraph(index);
        //console.log(conceptualMapDrawers);
      });
    }
  }, [conceptualMapDrawers, combinedEGsMaker, manualBigEGsFromDSM]);

  useEffect(() => {
    if (conceptualMapDrawer && combinedEGsMaker) {
      const engagementGroupIndex = 0;

      drawGraph(engagementGroupIndex);
    }
  }, [conceptualMapDrawer, combinedEGsMaker]);

  useEffect(() => {
    if (!dataStructureManager) {
      if (
        debateNameOfQuery === "sample" ||
        debateNameOfQuery === "기본소득" ||
        debateNameOfQuery === "정시확대" ||
        debateNameOfQuery === "모병제" ||
        debateNameOfQuery === "기본소득clipped" ||
        debateNameOfQuery === "정시확대clipped" ||
        debateNameOfQuery === "모병제clipped"
      ) {
        const dataImporter = new DataImporter(
          debateNameOfQuery,
          termTypeOfQuery
        );

        const dataStructureMaker = new DataStructureManager(
          debateNameOfQuery,
          dataImporter.debateDataSet!
        );

        const combinedEGsMaker = new CombinedEGsMaker(
          dataStructureMaker.dataStructureSet.similarityBlockManager.similarityBlockGroup,
          dataImporter.debateDataSet!.utteranceObjects
        );
        console.log(
          dataStructureMaker.datasetOfManualEGs.manualBigEGTitles,
          dataStructureMaker.datasetOfManualEGs.manualBigEGs
        );
        dispatch({
          type: CHANGE_STANDARD_SIMILARITY_SCORE,
          payload: {
            standardSimilarityScore:
              dataStructureMaker.dataStructureSet.maxSimilarityScore,
          },
        });

        setDebateDataset(dataImporter.debateDataSet);
        setDataStructureManager(dataStructureMaker);
        setCombinedEGsMaker(combinedEGsMaker);
        setEvaluationDataSet(dataImporter.evaluationDataSet);
      }
    }
  }, []);

  // useEffect(() => {
  //   if (dataStructureManager && debateDataset) {
  //     const dataStructureSet = dataStructureManager.dataStructureSet;
  //     const datasetOfManualEGs = dataStructureManager.datasetOfManualEGs;
  //     const manualBigEGs = datasetOfManualEGs.manualBigEGs;
  //     const manualBigEGTitles = datasetOfManualEGs.manualBigEGTitles;
  //     const engagementGroupIndex = 0;
  //     const engagementGroup = props.manualBigEGs[engagementGroupIndex]; // 또는 state로 관리되는 경우 state.manualBigEGs[engagementGroupIndex]
  //     drawGraph(engagementGroupIndex);
  //     console.log(manualBigEGs);
  //   }
  // }, []);

  useImperativeHandle(ref, () => ({
    openModal,
  }));

  // conceptualMapDrawers.forEach((drawer, index) => {
  //   const domElementInfo = drawer.getDomElementInfo();
  //   const className = domElementInfo.divClassName.replace(".", "");
  //   console.log(
  //     `Engagement groups for DOM element with class '${className}':`,
  //     drawer.getEngagementGroups()
  //   );
  // });

  return (
    <div className={styles.conceptualMapModalContent} ref={modalRef}>
      <div
        className="concept-recurrence-plot"
        style={{
          marginLeft: "0px",
          display: "flex",
          flexDirection: "row",
          //alignItems: "center",
          flexWrap: "wrap",
          justifyContent: "center",
        }}
      >
        {conceptualMapDrawers.map((_, index) => (
          <div key={index} className={`${conceptualMapDivClassName}-${index}`}>
            <div className="topicPos">{modalTitle}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default forwardRef(ConceptualMapModal);
