import Narrative from './narrative';
export default Narrative;
