import React, { Component } from "react";
import { ReactPropTypes } from "react";
import Narrative from "./index";
// import from './narrative.scss';

function Narratives() {
  return <div className="wrap"></div>;
}

export default Narratives;
