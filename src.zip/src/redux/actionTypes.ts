// export const ADD_TODO = "ADD_TODO";
// export const TOGGLE_TODO = "TOGGLE_TODO";
// export const SET_FILTER = "SET_FILTER";

export const CHANGE_STANDARD_SIMILARITY_SCORE =
  "CHANGE_STANDARD_SIMILARITY_SCORE";
