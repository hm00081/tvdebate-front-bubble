import Nlp from './nlp';

export default Nlp;
