/* eslint-disable no-unused-vars */
import React, { useEffect } from "react";
import styles from "./SubjectTestEnd.module.scss";

interface ComponentProps {}

function SubjectTestEnd(props: ComponentProps) {
  useEffect(() => {}, []);

  return <div className={styles.component}></div>;
}

export default SubjectTestEnd;
